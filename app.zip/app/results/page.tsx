"use client";

// =========================================================
// Imports
// =========================================================
import { useEffect, useMemo, useState } from "react";
import Papa from "papaparse";



// =========================================================
// Types
// =========================================================
type Card = {
  card_name: string;
  issuer: string;
  card_type: string;
  annual_fee: string;
  reward_model: string;
  cashback_rate_effective: string;
  estimated_bonus_value_usd: string;
  intro_apr_purchase: string;
};

type Answers = {
  [key: string]: string;
};



// =========================================================
// Issuer Color Map
// =========================================================
const issuerColors: Record<string, { bg: string; text: string }> = {
  chase: { bg: "#1e3a8a", text: "#ffffff" },
  amex: { bg: "#e5e7eb", text: "#0f172a" },
  citi: { bg: "#2563eb", text: "#ffffff" },
  "bank of america": { bg: "#dc2626", text: "#ffffff" },
  "capital one": { bg: "#dc2626", text: "#ffffff" },
  barclays: { bg: "#e0f2fe", text: "#075985" }
};

function getIssuerStyle(issuer: string) {
  return issuerColors[issuer.toLowerCase()] || {
    bg: "#e5e7eb",
    text: "#111827"
  };
}



// =========================================================
// Refinement Questions Config
// =========================================================
const refinementQuestions = [
  {
    id: "cards_24mo",
    label: "How many credit cards have you opened in the last 24 months?",
    dependsOn: () => true,
    options: ["0–4", "5", "6", "7+"]
  },
  {
    id: "travel_rewards_type",
    label: "What kind of travel rewards do you prefer?",
    dependsOn: (answers: Answers) => answers.primary_goal === "Travel",
    options: ["Generic / flexible travel", "Airline-specific", "Hotel-specific"]
  },
  {
    id: "preferred_airline",
    label: "Which airline do you usually fly?",
    dependsOn: (answers: Answers) =>
      answers.travel_rewards_type === "Airline-specific",
    options: [
      "United",
      "Delta",
      "American",
      "Alaska",
      "JetBlue",
      "Southwest",
      "No strong preference"
    ]
  },
  {
    id: "preferred_hotel",
    label: "Which hotel brand do you prefer?",
    dependsOn: (answers: Answers) =>
      answers.travel_rewards_type === "Hotel-specific",
    options: ["Marriott", "Hilton", "Hyatt", "IHG", "No strong preference"]
  },
  {
    id: "needs_0_apr",
    label: "Do you need a 0% intro APR?",
    dependsOn: (answers: Answers) => answers.primary_goal !== "Travel",
    options: ["Yes, I plan to carry a balance", "No, I pay in full", "Doesn't matter"]
  }
];



// =========================================================
// Helper Functions
// =========================================================
function hasIntroAPR(card: Card) {
  return card.intro_apr_purchase?.trim().startsWith("0%");
}

function issuerExcluded(issuer: string, cards24mo: string) {
  const i = issuer.toLowerCase();
  if (cards24mo === "5") return i === "chase";
  if (cards24mo === "6") return i === "chase" || i === "citi";
  if (cards24mo === "7+") return i === "chase" || i === "citi" || i === "amex";
  return false;
}



// =========================================================
// Scoring Engine
// =========================================================
function scoreCard(card: Card, answers: Answers, ownedCards: string[]) {
  if (ownedCards.includes(card.card_name)) return -9999;
  if (card.card_type !== answers.card_mode) return -9999;
  if (issuerExcluded(card.issuer, answers.cards_24mo)) return -9999;

  let score = 0;

  if (
    answers.needs_0_apr === "Yes, I plan to carry a balance" &&
    answers.primary_goal !== "Travel"
  ) {
    if (!hasIntroAPR(card)) return -9999;
    score += parseFloat(card.cashback_rate_effective || "0") * 10;
    score -= parseInt(card.annual_fee || "0", 10) / 10;
    return score;
  }

  if (answers.primary_goal === "Travel") {
    score += card.reward_model === "Travel" ? 60 : -25;
  }

  if (
    answers.preferred_airline &&
    answers.preferred_airline !== "No strong preference" &&
    card.card_name.includes(answers.preferred_airline)
  ) score += 40;

  if (
    answers.preferred_hotel &&
    answers.preferred_hotel !== "No strong preference" &&
    card.card_name.includes(answers.preferred_hotel)
  ) score += 40;

  score += Math.min(
    parseInt(card.estimated_bonus_value_usd || "0", 10) / 100,
    20
  );

  return score;
}



// =========================================================
// Main Results Page
// =========================================================
export default function ResultsPage() {

  const [cards, setCards] = useState<Card[]>([]);
  const [answers, setAnswers] = useState<Answers>({});
  const [ownedCards, setOwnedCards] = useState<string[]>([]);
  const [rankedCards, setRankedCards] = useState<Card[]>([]);



  // ---------------------
  // Load Initial Data
  // ---------------------
  useEffect(() => {
    const storedAnswers = JSON.parse(localStorage.getItem("answers") || "{}");
    const cardMode = localStorage.getItem("card_mode");
    setAnswers({ ...storedAnswers, card_mode: cardMode || "" });

    fetch("/cards.csv")
      .then(res => res.text())
      .then(text => {
        const parsed = Papa.parse<Card>(text, {
          header: true,
          skipEmptyLines: true
        });
        setCards(parsed.data);
      });
  }, []);



  // ---------------------
  // Live Re-Scoring
  // ---------------------
  useEffect(() => {
    const scored = [...cards]
      .map(card => ({
        card,
        score: scoreCard(card, answers, ownedCards)
      }))
      .sort((a, b) => b.score - a.score)
      .map(x => x.card);

    setRankedCards(scored);
  }, [cards, answers, ownedCards]);



  // ---------------------
  // Issuer Warnings
  // ---------------------
  const issuerWarnings = useMemo(() => {
    if (!answers.cards_24mo) return [];
    if (answers.cards_24mo === "5")
      return ["Chase cards may not be available due to Chase 5/24 rules."];
    if (answers.cards_24mo === "6")
      return ["Chase and Citi cards may not be available due to issuer approval rules."];
    if (answers.cards_24mo === "7+")
      return ["Chase, Citi, and Amex cards may not be available due to issuer approval rules."];
    return [];
  }, [answers.cards_24mo]);



  // ---------------------
  // Refinement Visibility
  // ---------------------
  const hasAnsweredCards24mo = Boolean(answers.cards_24mo);
  const visibleRefinements = refinementQuestions.filter(q => {
    if (q.id === "cards_24mo") return true;
    if (!hasAnsweredCards24mo) return false;
    return q.dependsOn ? q.dependsOn(answers) : true;
  });



  // =========================================================
  // UI
  // =========================================================
  return (
    <div style={{ display: "grid", gridTemplateColumns: "360px 1fr", gap: 40, padding: 40, background: "#f8fafc" }}>

      {/* LEFT PANEL */}
      <div style={{ background: "#ffffff", borderRadius: 12, padding: 20 }}>
        {issuerWarnings.length > 0 && (
          <div style={{ background: "#fff7ed", border: "1px solid #fdba74", padding: 12, borderRadius: 8, marginBottom: 20 }}>
            {issuerWarnings.map(w => (
              <div key={w} style={{ fontSize: 14 }}>{w}</div>
            ))}
          </div>
        )}

        <h3 style={{ marginBottom: 16 }}>Refine your results</h3>

        {visibleRefinements.map(q => (
          <div key={q.id} style={{ marginBottom: 20 }}>
            <div style={{ fontWeight: 500, marginBottom: 8 }}>{q.label}</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
              {q.options.map(option => (
                <button
                  key={option}
                  onClick={() => setAnswers(prev => ({ ...prev, [q.id]: option }))}
                  style={{
                    padding: "6px 12px",
                    borderRadius: 999,
                    border: "1px solid #c7d2fe",
                    background: answers[q.id] === option ? "#2563eb" : "#eef2ff",
                    color: answers[q.id] === option ? "#ffffff" : "#1e3a8a"
                  }}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>



      {/* RIGHT PANEL */}
      <div>
        <h2 style={{ marginBottom: 20 }}>Best cards for you</h2>

        {rankedCards.slice(0, 5).map(card => {
          const style = getIssuerStyle(card.issuer);
          return (
            <div
              key={card.card_name}
              style={{
                background: "#ffffff",
                borderRadius: 12,
                padding: 16,
                marginBottom: 12,
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                boxShadow: "0 1px 3px rgba(0,0,0,0.08)"
              }}
            >
              <div>
                <strong>{card.card_name}</strong>
                <div style={{ fontSize: 13, color: "#475569", marginTop: 4 }}>
                  <span
                    style={{
                      background: style.bg,
                      color: style.text,
                      padding: "2px 8px",
                      borderRadius: 999,
                      fontSize: 12
                    }}
                  >
                    {card.issuer}
                  </span>
                  {card.intro_apr_purchase ? ` • ${card.intro_apr_purchase}` : ""}
                </div>
              </div>

              <label style={{ fontSize: 13 }}>
                <input
                  type="checkbox"
                  checked={ownedCards.includes(card.card_name)}
                  onChange={() =>
                    setOwnedCards(prev =>
                      prev.includes(card.card_name)
                        ? prev.filter(c => c !== card.card_name)
                        : [...prev, card.card_name]
                    )
                  }
                />{" "}
                I already have this
              </label>
            </div>
          );
        })}

        {ownedCards.length > 0 && (
          <>
            <h3 style={{ marginTop: 32, marginBottom: 12 }}>
              Cards you already have
            </h3>

            {ownedCards.map(name => (
              <div
                key={name}
                style={{
                  background: "#f1f5f9",
                  borderRadius: 8,
                  padding: 12,
                  marginBottom: 8,
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center"
                }}
              >
                <span>{name}</span>
                <label style={{ fontSize: 13 }}>
                  <input
                    type="checkbox"
                    checked={true}
                    onChange={() =>
                      setOwnedCards(prev =>
                        prev.filter(c => c !== name)
                      )
                    }
                  />{" "}
                  Remove
                </label>
              </div>
            ))}
          </>
        )}
      </div>

    </div>
  );
}
