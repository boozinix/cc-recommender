"use client";

// =======================
// Imports
// =======================
import { useState } from "react";



// =======================
// Questions Config (TEXT UPDATED ONLY)
// =======================
const questions = [
  {
    id: "primary_goal",
    question: "What do you want this card to be best at?",
    options: [
      { value: "Cashback", label: "💰 Highest cashback overall" },
      { value: "Travel", label: "✈️ Travel rewards & points" },
      { value: "Bonus", label: "🎁 Big signup bonus" },
      { value: "Everyday", label: "🧾 Everyday spending" }
    ]
  },
  {
    id: "annual_fee_tolerance",
    question: "How do you feel about annual fees?",
    options: [
      { value: "None", label: "❌ No annual fee" },
      { value: "Low", label: "🙂 Up to $95" },
      { value: "Medium", label: "😐 $95–$250" },
      { value: "High", label: "😎 Doesn't matter" }
    ]
  },
  {
    id: "spend_comfort",
    question: "How comfortable are you meeting a spending requirement?",
    options: [
      { value: "Low", label: "Low ($1k or less)" },
      { value: "Medium", label: "Medium ($3k)" },
      { value: "High", label: "High ($5k+)" }
    ]
  },
  {
    id: "travel_frequency",
    question: "How often do you travel?",
    options: [
      { value: "Low", label: "Rarely" },
      { value: "Medium", label: "A few times a year" },
      { value: "High", label: "Frequently" }
    ]
  }
];



// =======================
// Fade Animation CSS
// =======================
const fadeInStyle = `
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
`;



// =======================
// Main Wizard Page
// =======================
export default function Wizard() {

  // -----------------------
  // State
  // -----------------------
  const [cardMode, setCardMode] = useState<"personal" | "business" | null>(null);
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<any>({});

  const currentQuestion = questions[step];



  // -----------------------
  // Handle Card Mode Toggle
  // (HARD RESET RULE)
  // -----------------------
  function handleModeChange(mode: "personal" | "business") {
    if (cardMode && cardMode !== mode) {
      setStep(0);
      setAnswers({});
      localStorage.removeItem("answers");
    }

    setCardMode(mode);
    localStorage.setItem("card_mode", mode);
  }



  // -----------------------
  // Handle Answer
  // -----------------------
  function handleAnswer(optionValue: string) {
    const updatedAnswers = {
      ...answers,
      [currentQuestion.id]: optionValue
    };

    setAnswers(updatedAnswers);

    if (step === questions.length - 1) {
      localStorage.setItem("answers", JSON.stringify(updatedAnswers));
      window.location.href = "/results";
    } else {
      setStep(step + 1);
    }
  }



  // =======================
  // UI
  // =======================
  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        padding: "0 20px",
        fontFamily: "system-ui",
        background: "radial-gradient(circle at top, #eef2ff, #ffffff)"
      }}
    >
      {/* Inject animation CSS */}
      <style>{fadeInStyle}</style>



      {/* =======================
          Personal / Business Toggle
         ======================= */}
      <div style={{ display: "flex", gap: 12, marginBottom: 28 }}>
        <button
          onClick={() => handleModeChange("personal")}
          style={{
            padding: "10px 20px",
            borderRadius: 999,
            border: "2px solid #2563eb",
            background: cardMode === "personal" ? "#2563eb" : "#fff",
            color: cardMode === "personal" ? "#fff" : "#2563eb",
            cursor: "pointer",
            fontWeight: 600
          }}
        >
          Personal
        </button>

        <button
          onClick={() => handleModeChange("business")}
          style={{
            padding: "10px 20px",
            borderRadius: 999,
            border: "2px solid #2563eb",
            background: cardMode === "business" ? "#2563eb" : "#fff",
            color: cardMode === "business" ? "#fff" : "#2563eb",
            cursor: "pointer",
            fontWeight: 600
          }}
        >
          Business
        </button>
      </div>



      {/* =======================
          Block Until Mode Selected
         ======================= */}
      {!cardMode && (
        <div style={{ color: "#6b7280", marginBottom: 24 }}>
          Select Personal or Business to begin.
        </div>
      )}



      {/* =======================
          Progress Bar
         ======================= */}
      {cardMode && (
        <div style={{ width: 300, marginBottom: 24 }}>
          <div style={{ fontSize: 14, marginBottom: 6 }}>
            Step {step + 1} of {questions.length}
          </div>
          <div style={{ height: 6, background: "#e5e7eb", borderRadius: 4 }}>
            <div
              style={{
                height: 6,
                width: `${((step + 1) / questions.length) * 100}%`,
                background: "#2563eb",
                borderRadius: 4,
                transition: "width 0.3s ease"
              }}
            />
          </div>
        </div>
      )}



      {/* =======================
          Question + Options
          (fade animation here)
         ======================= */}
      {cardMode && (
        <div
          key={step}
          style={{
            animation: "fadeIn 0.3s ease",
            textAlign: "center"
          }}
        >
          <h2 style={{ marginBottom: 32 }}>
            {currentQuestion.question}
          </h2>

          <div
            style={{
              width: "100%",
              maxWidth: 420,
              display: "grid",
              gap: 16
            }}
          >
            {currentQuestion.options.map(option => (
              <button
                key={option.value}
                onClick={() => handleAnswer(option.value)}
                style={{
                  padding: "16px 24px",
                  fontSize: 18,
                  borderRadius: 10,
                  border: "2px solid #ccc",
                  cursor: "pointer",
                  background: "#fff",
                  boxShadow: "0 4px 6px rgba(0,0,0,0.05)",
                  transition: "all 0.15s ease"
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.transform = "translateY(-2px)";
                  e.currentTarget.style.boxShadow =
                    "0 8px 14px rgba(0,0,0,0.1)";
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.transform = "translateY(0)";
                  e.currentTarget.style.boxShadow =
                    "0 4px 6px rgba(0,0,0,0.05)";
                }}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
